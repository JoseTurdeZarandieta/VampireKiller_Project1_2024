LINK TO GITHUB.COM


MEMBERS

José Tur de Zarandieta - - - - https://github.com/JoseTurdeZarandieta

GAME DESCRIPTION

Vampire Killer is a 2D platform game in which the player embraces the character of Simon Belmont, descendant of the Belmont clan. Following his obliged destiny, he must enter Dracula's Castle and slay him, to return peace once again.

Vampire Killer was developed and published by Konami in 1986 for the MSX2.


GAME CONTROLS


	Left Arrow: move left
	Right Arrow: move right
	Up Arrow: jump
	Down Arrow: crouch

	Enter: Attack

IMPLEMENTED FEATURES

	- 6 playable screens
	- player movement
	- 3 items (only give points)
